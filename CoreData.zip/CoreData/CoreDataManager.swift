//
//  CoreDataManager.swift
//  iCloudStorage
//
//  Created by mac on 17/01/23.
//

import Foundation
import CoreData
import Combine

class CoreDataManager: CoreDataServices {
    func saveData(model: EmployModel) -> AnyPublisher<Void, Error> {
        return Future<Void, Error> { promise in
            let managedContext = AppDelegate.sharedAppDelegate.coreDataStack.managedContext
            let employ = Employ(context: managedContext)
            employ.setValue(model.name, forKeyPath: #keyPath(Employ.name))
            employ.setValue(model.email, forKeyPath: #keyPath(Employ.email))
            employ.setValue(model.gender, forKeyPath: #keyPath(Employ.gender))
            employ.setValue(model.phoneno, forKeyPath: #keyPath(Employ.phoneno))
            employ.setValue(model.salary, forKeyPath: #keyPath(Employ.salary))
            do {
                try AppDelegate.sharedAppDelegate.coreDataStack.managedContext.save()
                promise(.success(()))
            } catch let error {
                promise(.failure(error))
            }
        }.eraseToAnyPublisher()
    }
    
    func getData() -> AnyPublisher<[Employ], Error> {
        return Future<[Employ], Error> { promise in
            let fetchEmploy: NSFetchRequest<Employ> = Employ.fetchRequest()
            let sortByName = NSSortDescriptor(key: #keyPath(Employ.name), ascending: false)
            fetchEmploy.sortDescriptors = [sortByName]
            do {
                let managedContext = AppDelegate.sharedAppDelegate.coreDataStack.managedContext
                let results = try managedContext.fetch(fetchEmploy)
                promise(.success(results))
            } catch let error {
                promise(.failure(error))
            }
        }.eraseToAnyPublisher()
    }
    
    func updateData(model: EmployModel) -> AnyPublisher<Void, Error> {
        return Future<Void, Error> { promise in
            let managedContext = AppDelegate.sharedAppDelegate.coreDataStack.managedContext
            let employ = Employ(context: managedContext)
            employ.setValue(model.name, forKeyPath: #keyPath(Employ.name))
            employ.setValue(model.email, forKeyPath: #keyPath(Employ.email))
            employ.setValue(model.gender, forKeyPath: #keyPath(Employ.gender))
            employ.setValue(model.phoneno, forKeyPath: #keyPath(Employ.phoneno))
            employ.setValue(model.salary, forKeyPath: #keyPath(Employ.salary))
            do {
                try AppDelegate.sharedAppDelegate.coreDataStack.managedContext.save()
                promise(.success(()))
            } catch let error {
                promise(.failure(error))
            }
        }.eraseToAnyPublisher()
    }
    
    func deleteData(model: Employ) -> AnyPublisher<Void, Error> {
        return Future<Void, Error> { promise in
            AppDelegate.sharedAppDelegate.coreDataStack.managedContext.delete(model)
            do {
                try AppDelegate.sharedAppDelegate.coreDataStack.managedContext.save()
                promise(.success(()))
            } catch let error {
                promise(.failure(error))
            }
        }.eraseToAnyPublisher()
    }
}
