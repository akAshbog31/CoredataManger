//
//  CoreDataServices.swift
//  iCloudStorage
//
//  Created by mac on 17/01/23.
//

import Foundation
import Combine

protocol CoreDataServices {
    func saveData(model: EmployModel) -> AnyPublisher<Void, Error>
    
    func getData() -> AnyPublisher<[Employ], Error>
    
    func updateData(model: EmployModel) -> AnyPublisher<Void, Error>
    
    func deleteData(model: Employ) -> AnyPublisher<Void, Error>
}
