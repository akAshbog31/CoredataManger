//
//  Employ+CoreDataProperties.swift
//  iCloudStorage
//
//  Created by mac on 17/01/23.
//
//

import Foundation
import CoreData


extension Employ {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Employ> {
        return NSFetchRequest<Employ>(entityName: "Employ")
    }

    @NSManaged public var id: UUID?
    @NSManaged public var name: String?
    @NSManaged public var email: String?
    @NSManaged public var phoneno: Int64
    @NSManaged public var gender: String?
    @NSManaged public var salary: Int32

}

extension Employ : Identifiable {

}
